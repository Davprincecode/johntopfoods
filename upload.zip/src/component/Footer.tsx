// import React from 'react'

function Footer() {
  return (
    <div>
      {/* <!-- ===========contact start====== --> */}
<div className="contactcontainer" id="contactcontainer">

    {/* <!-- <div className="contactheader">
        <h2>get in touch</h2>
        <h1>hey! let`s talk</h1>
    </div> --> */}

 <div className="contactflex">

    <div className="contactholder">
      <div className="contact1">
        <h4>location</h4>
        <p>
        Zone E Block 7 shop 3 Besides OGD TUTORS OAU CENTRAL MARKET, OAU ILE-IFE, OSUN STATE
        </p>
      </div>
    </div>

    <div className="contactholder">
        <div className="contact1">
          <h4>contact us</h4>
          <p>08057386375</p>
        </div>
    </div>

    <div className="contactholder">
        <div className="contact1">
          <h4>open hours</h4>
          <p>Open Daily: 8am - 10pm</p>
        </div>
    </div>
  
    <div className="contactholder">
        <div className="contact1">
          <h4>stay connected</h4>
          <div className="followflex">

            <a href="https://wa.me/08163861584">
              {/* <div className="followimg" style="width: 30px; height: 30px">
                  <img src="images/whatsapp.png" alt="" style="    width: 120%; height: 120%; padding-bottom: 9px;">
              </div> */}
            </a>

            <a href="">
              {/* <div className="followimg">
                  <img src="images/facebook.png" alt="">
              </div> */}
            </a>
               
            <a href="">
              {/* <div className="followimg">
                  <img src="images/instagram.png" alt="">
              </div> */}
            </a>


          </div>
        </div>
      </div>

 </div>

 <div className="underline"></div>
  <div className="copyright">
    copyright @ 2024 develop by davprincecode </div>
</div>

{/* <!-- ========contact end=========== --> */}
    </div>
  )
}

export default Footer

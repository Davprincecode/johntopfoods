// import React from 'react'

function Partner() {
  return (
    <div>Partner</div>
  )
}

export default Partner
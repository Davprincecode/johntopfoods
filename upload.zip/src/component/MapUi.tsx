// import React from 'react'

function MapUi() {
  return (
    <div>
        {/* allowFullScreen="" */}
        {/* referrerpolicy="no-referrer-when-downgrade" */}
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15823.396101924998!2d4.5343569!3d7.4819181!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103837d4dcc2a751%3A0x4c2dac2867d9c8a0!2sJohntop%20foods!5e0!3m2!1sen!2sng!4v1715866993663!5m2!1sen!2sng"
         width="600" height="450" style={{border:"0"}}  
         loading="lazy" 
         >
            
         </iframe>
    </div>
  )
}

export default MapUi